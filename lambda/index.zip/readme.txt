Upload to lambda:
Create zip file from code
aws lambda update-function-code --function-name gameServerAdmin --zip-file fileb://index.zip
