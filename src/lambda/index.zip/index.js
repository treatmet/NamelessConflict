global.updateEB = process.env.updateEB;
global.mongoDbLocation = process.env.mongoDbLocation;
global.s3LoggingBucket = process.env.s3LoggingBucket;
global.EBName = process.env.EBName;
global.serverHealthCheckTimestampThreshold = process.env.serverHealthCheckTimestampThreshold; 
global.stalePartyRequestThreshold = process.env.stalePartyRequestThresholdDays; //30 (Days)
global.staleFriendRequestThreshold = process.env.staleFriendRequestThresholdSeconds; //300 (Seconds)

var AWS = require("aws-sdk");
var elasticbeanstalk = new AWS.ElasticBeanstalk();
var runningLocally = false;

//Running locally
if (!EBName){
    var localConfig = require("./config.json");
    if (localConfig){
        console.log("Running locally...");
        runningLocally = true;
        updateEB = localConfig.updateEB;
        mongoDbLocation = localConfig.mongoDbLocation;
        s3LoggingBucket = localConfig.s3LoggingBucket;
        EBName = localConfig.EBName;
        serverHealthCheckTimestampThreshold = localConfig.serverHealthCheckTimestampThreshold; 
        stalePartyRequestThreshold = localConfig.stalePartyRequestThresholdDays; //30 (Days)
        staleFriendRequestThreshold = localConfig.staleFriendRequestThresholdSeconds; //300 (Seconds)

    }
    else {
        console.log("ERROR - NO ENVIRONMENT VARIABLES OR config.json FOUND!!!");
    }
}

require('./code/logEngine.js');
const dataAccess = require('./code/dataAccess.js');

if (runningLocally){
    executeFunction({}, {}, function(nully, text){});
}

exports.handler = (event, context, callback) => {
    executeFunction(event, context, callback);
};

function executeFunction(event, context, callback){
    context.callbackWaitsForEmptyEventLoop = false;


    removeStaleRequests(function(){
        removeStaleServers(function(){
            getPublicServersFromDB(function(res){
                retrieveEnvironmentInfo(function(info){

                    var count = getServerCount(res);

                    log("fullServers: " + count.fullServers);
                    log("emptyServers: " + count.emptyServers);
                    log("playableServers: " + count.playableServers);
                    log("Updating EB instance count...");
    
                    updateInstanceCount(3, function(){
                        log("EB updateInstnceCount callback");
                        callback(null, "fullServers: " + count.fullServers);
                    });    


                });
            });	
        });
    });

}

function retrieveEnvironmentInfo(cb){
    //Get curent EB instance count
    //elasticbeanstalk.RetrieveEnvironmentInfo
    log("Inside retrieve env info");
    var info = {};

    cb(info);

}

function getServerCount(res){
    var count = {
        fullServers:0,
        emptyServers:0,
        playableServers:0
    };
    
    for (var s = 0; s < res.length; s++){
        var players = getCurrentNumPlayers(res[s].currentUsers);
        if (players >= res[s].maxPlayers){
            count.fullServers++;
        }
        else {
            count.playableServers++;
        }
        if (players == 0){
            count.emptyServers++;
        }
    }	
    return count;
}


function removeStaleRequests(cb){
    logg("removing stale friend requests and party requets...");
	removeStaleFriendRequests(function(fsuccess){
        removeStalePartyRequests(function(psuccess){
            cb();
        });
    });
}

function removeStaleFriendRequests(cb){
    var miliInterval = (staleFriendRequestThreshold * 1000 * 60 * 60 * 24);
	var thresholdDate = new Date(Date.now() - miliInterval);
	var searchParams = { type:"friend", timestamp:{ $lt: thresholdDate } };

	dataAccess.dbUpdateAwait("RW_REQUEST", "rem", searchParams, {}, async function(err, res){
		if (err){
			logg("DB ERROR - removeStaleFriendRequests() - RW_REQUEST.remove: " + err);
            cb(false);
		}
        else {
            logg("removed " + res + " stale friend requests");
            cb(true);
        }
	});
}

function removeStalePartyRequests(cb){
	var miliInterval = (stalePartyRequestThreshold * 1000);
	var thresholdDate = new Date(Date.now() - miliInterval);
	var searchParams = { type:"party", timestamp:{ $lt: thresholdDate } };
	
	dataAccess.dbUpdateAwait("RW_REQUEST", "rem", searchParams, {}, async function(err, res){
		if (err){
			logg("DB ERROR - removeStalePartyRequests() - RW_REQUEST.remove: " + err);
            cb(false);
		}
        else {
            logg("removed " + res + " stale party requests");
            cb(true);
        }
	});
}

function removeStaleServers(cb){
    logg("Removing stale servers from DB...");
    var acceptableLastHealthCheckTime = new Date();
    acceptableLastHealthCheckTime.setSeconds(acceptableLastHealthCheckTime.getUTCSeconds() - serverHealthCheckTimestampThreshold);
    var searchParams = { healthCheckTimestamp:{ $lt: acceptableLastHealthCheckTime } };
    dataAccess.dbUpdateAwait("RW_SERV", "rem", searchParams, {}, async function(err2, obj){
        if (!err2){
            logg("Unhealthy Servers successfully removed from database.");
        }
        cb();
    });	
}

function updateInstanceCount(targetCount, cb){
    if (updateEB == 0){
        log("WARNING! CURRENTLY CONFIGURED TO SKIP BEANSTALK UPDATE. Would have updated to " + targetCount);
        cb();
        return;
    }
    
    var params = {
        EnvironmentName: EBName, 
        OptionSettings: [
            {
                Namespace: "aws:autoscaling:asg", 
                OptionName: "MinSize", 
                Value: targetCount.toString()
            }, 
            {
                Namespace: "aws:autoscaling:asg", 
                OptionName: "MaxSize", 
                Value: targetCount.toString()
            } 
        ]
    };

    elasticbeanstalk.updateEnvironment(params, function(err, data) {
        if (err){ 
            log("ERROR FAILED BEANSTALK UPDATE");
            log(err, err.stack); // an error occurred
        }
        else {
            log("BEANSTALK UPDATE SUCCESS!!!");
            log(data);           // successful response
        }
        cb();

        /*
        "OptionName": "MinSize",
        "OptionName": "MaxSize"

        data = {
         ApplicationName: "my-app", 
         CNAME: "my-env.elasticbeanstalk.com", 
         DateCreated: <Date Representation>, 
         DateUpdated: <Date Representation>, 
         EndpointURL: "awseb-e-i-AWSEBLoa-1RDLX6TC9VUAO-0123456789.us-west-2.elb.amazonaws.com", 
         EnvironmentId: "e-szqipays4h", 
         EnvironmentName: "my-env", 
         Health: "Grey", 
         SolutionStackName: "64bit Amazon Linux running Tomcat 7", 
         Status: "Updating", 
         Tier: {
          Name: "WebServer", 
          Type: "Standard", 
          Version: " "
         }, 
         VersionLabel: "v2"
        }
        */
        
      });

}

function getPublicServersFromDB(cb){
	var servers = [];
	dataAccess.dbFindAwait("RW_SERV", {privateServer:false}, function(err,res){
		if (res && res[0]){
				
			for (var i = 0; i < res.length; i++){

				if (res[i].gametype == "ctf"){
					res[i].gametype = "CTF";
				}

				servers.push(res[i]);
			}					
        }
        cb(servers);
	});
}

function getCurrentNumPlayers(currentUsers){
    var players = 0;
    for (var u = 0; u < currentUsers.length; u++){
        if (currentUsers[u].team == 0 || currentUsers[u].team == 1 || currentUsers[u].team == 2)
            players++;
    }
    return players;
}
