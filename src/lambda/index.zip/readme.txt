Upload to lambda:
Create zip file from code
aws lambda update-function-code --function-name gameServerAdmin --zip-file fileb://index.zip

Test Locally:
Don't (for now). It is so fast to upload and test in Lambda.
